CuraEngine {#mainpage}
=======

This is the documentation for CuraEngine, the back-end slicer of Cura.

[Overview](documentation/overview.md)

[Glossary](documentation/glossary.md)

[Code Conventions](documentation/code_conventions.md)
