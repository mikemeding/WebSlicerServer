Things to add later
===================

- Support for Unix file sockets in addition to streamed local TCP sockets.
- Support for DNS resolving.
- Find some way to unit test this.
- Use a hash function on the message type name to automatically determine message type id.
- Improve error handling / checking.
